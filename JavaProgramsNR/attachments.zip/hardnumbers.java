package logicalprograms;

public class hardnumbers {

	public static void main(String[] args) {
		
	}

}
