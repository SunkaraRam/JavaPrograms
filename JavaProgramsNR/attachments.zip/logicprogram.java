package logicalprograms;

public class logicprogram 
{

	public static void main(String[] args) 
	{
		String x="hello";
		String y="world";
		int a=100;
		int b=200;
		System.out.println(x+y);
		System.out.println(a+b);
		System.out.println(a+b+x+y);
		System.out.println(x+y+(a+b));
    

	}

}
