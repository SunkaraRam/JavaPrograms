package logicalprograms;

public class evennumbers {

	public static void main(String[] args) {
		
	}

}
