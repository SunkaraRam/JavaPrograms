package logicalprograms;

public class primenumbers {

	public static void main(String[] args) {
		

	}

}
