package logicalprograms;

public class factorialnumber 
{
	public static void main(String[] args) 
	{
		int i,number=5,fact=1;
	       for (int j = 1; j <= number; j++) 
	       {
			fact=fact*j;
		}
	       System.out.println(fact);


	}

}
